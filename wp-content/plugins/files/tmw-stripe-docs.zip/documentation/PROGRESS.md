# TMW Stripe Subscriptions Plugin - Development Progress

## Project Overview
**Goal:** Replace WP Simple Membership with custom Stripe subscription plugin while maintaining compatibility with existing GarageMinder integration.

**Repositories:**
- WordPress Theme: https://github.com/eldridgedall0/tmw-wp
- GarageMinder App: https://github.com/eldridgedall0/garageminder

---

## Configuration Decisions (CONFIRMED)

| Setting | Decision |
|---------|----------|
| Stripe settings location | Separate tab in TMW admin |
| Tier editor Stripe fields | Show/hide based on `membership_plugin` setting |
| Subscribers management | Yes - basic info only (subscription ID, status, dates) |
| New user registration | Free tier by default (configurable) |
| Template changes | Modify to use generic functions |
| Pricing periods | Both monthly AND yearly per tier |
| Free trial | 7 days (configurable), one-time per user |
| Prorated upgrades | Charge difference immediately |
| Cancel behavior | Access until period end |

---

## Plugin Structure

```
tmw-stripe-subscriptions/
├── tmw-stripe-subscriptions.php          # Main plugin file
├── uninstall.php                         # Cleanup on uninstall
├── includes/
│   ├── class-tmw-stripe-loader.php       # Hook registration
│   ├── class-tmw-stripe-activator.php    # Activation tasks
│   ├── class-tmw-stripe-deactivator.php  # Deactivation tasks
│   ├── class-tmw-stripe-api.php          # Stripe API wrapper
│   ├── class-tmw-stripe-webhook.php      # Webhook handler
│   ├── class-tmw-stripe-checkout.php     # Checkout session creation
│   ├── class-tmw-stripe-portal.php       # Customer portal redirect
│   ├── class-tmw-stripe-subscription.php # Subscription management
│   └── class-tmw-stripe-adapter.php      # Membership adapter implementation
├── admin/
│   ├── class-tmw-stripe-admin.php        # Admin functionality
│   ├── partials/
│   │   ├── settings-stripe-tab.php       # Stripe settings tab
│   │   ├── tier-stripe-fields.php        # Tier modal Stripe fields
│   │   └── subscribers-page.php          # Subscribers management
│   └── js/
│       └── tmw-stripe-admin.js           # Admin JavaScript
├── public/
│   ├── class-tmw-stripe-public.php       # Public-facing functionality
│   └── js/
│       └── tmw-stripe-public.js          # Frontend JavaScript (checkout)
└── languages/
    └── tmw-stripe-subscriptions.pot      # Translation template
```

---

## Development Phases

### Phase 1: Core Plugin Structure ⬜
- [ ] Main plugin file with constants and loading
- [ ] Activation/deactivation hooks
- [ ] Loader class for hook registration
- [ ] Basic admin menu integration

### Phase 2: Stripe API Integration ⬜
- [ ] Stripe PHP SDK integration (via Composer or bundled)
- [ ] API wrapper class with error handling
- [ ] Test/Live mode switching
- [ ] Connection verification

### Phase 3: Admin Settings ⬜
- [ ] Stripe settings tab (API keys, webhook URL, options)
- [ ] Tier modal Stripe fields (show/hide based on plugin selection)
- [ ] JavaScript for conditional field display
- [ ] Settings sanitization and validation

### Phase 4: Membership Adapter ⬜
- [ ] Create `class-tmw-stripe-adapter.php` implementing interface
- [ ] Register adapter in theme's membership-adapter.php
- [ ] User tier detection from meta
- [ ] Subscription status checking
- [ ] Expiry date handling

### Phase 5: Checkout Flow ⬜
- [ ] Checkout session creation
- [ ] Monthly/yearly price selection
- [ ] Trial period handling (configurable days)
- [ ] One-time trial tracking per user
- [ ] Success/cancel redirects

### Phase 6: Webhook Handler ⬜
- [ ] REST API endpoint registration
- [ ] Signature verification
- [ ] Event handlers:
  - [ ] checkout.session.completed
  - [ ] customer.subscription.created
  - [ ] customer.subscription.updated
  - [ ] customer.subscription.deleted
  - [ ] invoice.payment_succeeded
  - [ ] invoice.payment_failed
- [ ] User meta updates
- [ ] Action hooks for theme integration

### Phase 7: Customer Portal ⬜
- [ ] Portal session creation
- [ ] Redirect handling
- [ ] Configuration (allow upgrades, downgrades, cancellation)

### Phase 8: Subscribers Management ⬜
- [ ] Admin page for viewing subscribers
- [ ] List table with:
  - [ ] User (name/email)
  - [ ] Tier
  - [ ] Status
  - [ ] Stripe subscription ID
  - [ ] Current period end
  - [ ] Actions (view in Stripe, sync)
- [ ] Filtering by tier/status
- [ ] Manual sync button
- [ ] Search functionality

### Phase 9: Template Function Updates ⬜
- [ ] Create generic `tmw_get_subscribe_url($tier, $period)` 
- [ ] Create generic `tmw_get_manage_subscription_url()`
- [ ] Update `template-pricing.php`
- [ ] Update `template-profile.php`
- [ ] Update `template-renewal.php`
- [ ] Remove/replace SWPM shortcodes

### Phase 10: Testing & Documentation ⬜
- [ ] Test mode verification
- [ ] Webhook testing with Stripe CLI
- [ ] Upgrade/downgrade flow testing
- [ ] Cancellation flow testing
- [ ] Trial period testing
- [ ] Documentation updates

---

## Files to Modify in tmw-wp Theme

| File | Changes |
|------|---------|
| `inc/membership-adapter.php` | Add `case 'stripe':` to factory function |
| `inc/admin-settings.php` | Add Stripe tab, conditional tier fields |
| `templates/template-pricing.php` | Use generic subscribe URL function |
| `templates/template-profile.php` | Use generic manage subscription URL |
| `templates/template-renewal.php` | Use generic URLs throughout |
| `inc/subscription.php` | Add generic URL helper functions |

---

## Database Storage (User Meta)

| Meta Key | Description | Example |
|----------|-------------|---------|
| `tmw_stripe_customer_id` | Stripe customer ID | `cus_xxxxxxxxxxxxx` |
| `tmw_stripe_subscription_id` | Stripe subscription ID | `sub_xxxxxxxxxxxxx` |
| `tmw_subscription_tier` | Current tier slug | `paid` |
| `tmw_subscription_status` | Subscription status | `active`, `canceled`, `past_due` |
| `tmw_subscription_current_period_end` | Billing period end | `2026-03-01` |
| `tmw_subscription_ends_at` | For canceled subs | `2026-03-01` |
| `tmw_stripe_trial_used` | Has used free trial | `1` |
| `tmw_tier_changed` | Last tier change date | `2026-02-01 12:00:00` |

---

## WordPress Options

| Option | Description |
|--------|-------------|
| `tmw_stripe_settings` | Stripe API keys and configuration |
| `tmw_tiers` | Extended with `stripe_price_id_monthly`, `stripe_price_id_yearly` |

---

## Current Session Progress

### Completed ✅
1. Analyzed existing theme structure
2. Reviewed all relevant files:
   - `admin-settings.php` (tier/limit management)
   - `subscription.php` (tier logic)
   - `membership-adapter.php` (adapter pattern)
   - `simple-membership.php` adapter
   - `template-pricing.php`
   - `template-profile.php`
   - `template-renewal.php`
   - `template-functions.php`
3. Confirmed all configuration decisions with user
4. Created plugin structure plan
5. Created progress document
6. **Created all plugin files:**
   - Main plugin file (`tmw-stripe-subscriptions.php`)
   - Activator/Deactivator classes
   - Loader class
   - Stripe API wrapper class
   - Webhook handler class
   - Checkout session class
   - Customer Portal class
   - Membership adapter class
   - Admin class
   - Settings class
   - Subscribers list table class
   - Public class
   - All partial templates
   - All JavaScript files
   - Uninstall.php
7. Created theme modifications documentation
8. Created comprehensive project instructions

### In Progress 🔄
- Ready for testing and deployment

### Next Steps 📋
1. Copy plugin to WordPress installation
2. Activate plugin
3. Configure Stripe API keys in admin
4. Set up webhook in Stripe Dashboard
5. Create Stripe products and prices
6. Apply theme modifications
7. Test checkout flow
8. Test webhook handling
9. Test portal (upgrade/downgrade/cancel)

---

## Resume Instructions

If chat stops, start new conversation with:

```
I'm continuing development of the TMW Stripe Subscriptions plugin. 
Please read the progress document at:
/home/claude/tmw-stripe-plugin/PROGRESS.md

Current phase: [check last "In Progress" section]
Next task: [check "Next Steps" section]

Repository: https://github.com/eldridgedall0/tmw-wp
```

---

## Version History

| Version | Date | Changes |
|---------|------|---------|
| 0.0.1 | 2026-02-01 | Initial planning and structure |
