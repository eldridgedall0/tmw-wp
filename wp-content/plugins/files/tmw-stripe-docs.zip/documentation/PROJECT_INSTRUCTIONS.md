# TMW Stripe Subscriptions Plugin - Project Instructions

## Overview

The **TMW Stripe Subscriptions** plugin provides native Stripe subscription management for TrackMyWrench/GarageMinder, replacing the Simple Membership plugin while maintaining full compatibility with the existing theme architecture.

**Repository Location:** `wp-content/plugins/tmw-stripe-subscriptions/`

---

## Plugin Structure

```
tmw-stripe-subscriptions/
├── tmw-stripe-subscriptions.php      # Main plugin file (entry point)
├── uninstall.php                     # Cleanup on plugin deletion
│
├── includes/                         # Core plugin classes
│   ├── class-tmw-stripe-loader.php       # WordPress hooks manager
│   ├── class-tmw-stripe-activator.php    # Runs on plugin activation (creates tables)
│   ├── class-tmw-stripe-deactivator.php  # Runs on plugin deactivation
│   ├── class-tmw-stripe-api.php          # Stripe REST API wrapper (no SDK needed)
│   ├── class-tmw-stripe-webhook.php      # REST endpoint for Stripe webhooks
│   ├── class-tmw-stripe-checkout.php     # Creates Stripe Checkout sessions
│   ├── class-tmw-stripe-portal.php       # Stripe Customer Portal redirects
│   └── class-tmw-stripe-adapter.php      # Implements TMW_Membership_Adapter_Interface
│
├── admin/                            # Admin-specific functionality
│   ├── class-tmw-stripe-admin.php        # Admin menu, scripts, subscribers page
│   ├── class-tmw-stripe-settings.php     # Stripe settings tab logic
│   ├── class-tmw-stripe-subscribers.php  # WP_List_Table for subscribers
│   ├── js/
│   │   └── tmw-stripe-admin.js           # Admin JavaScript (settings, tier fields)
│   └── partials/
│       ├── settings-page.php             # Stripe settings tab HTML
│       ├── subscribers-page.php          # Subscribers list HTML
│       └── tier-stripe-fields.php        # Stripe fields for tier modal
│
├── public/                           # Frontend functionality
│   ├── class-tmw-stripe-public.php       # Public hooks, user registration
│   └── js/
│       └── tmw-stripe-public.js          # Checkout/portal JavaScript
│
└── languages/
    └── tmw-stripe-subscriptions.pot      # Translation template
```

---

## Key Classes

| Class | File | Purpose |
|-------|------|---------|
| `TMW_Stripe_Subscriptions` | tmw-stripe-subscriptions.php | Main plugin class, bootstraps everything |
| `TMW_Stripe_Loader` | class-tmw-stripe-loader.php | Registers WordPress hooks systematically |
| `TMW_Stripe_Activator` | class-tmw-stripe-activator.php | Creates database tables on activation |
| `TMW_Stripe_API` | class-tmw-stripe-api.php | Stripe REST API wrapper (customers, subscriptions, checkout) |
| `TMW_Stripe_Webhook` | class-tmw-stripe-webhook.php | REST endpoint `/wp-json/tmw-stripe/v1/webhook` |
| `TMW_Stripe_Checkout` | class-tmw-stripe-checkout.php | Creates Checkout Sessions with trial handling |
| `TMW_Stripe_Portal` | class-tmw-stripe-portal.php | Creates Customer Portal sessions |
| `TMW_Stripe_Adapter` | class-tmw-stripe-adapter.php | Implements theme's membership adapter interface |
| `TMW_Stripe_Admin` | class-tmw-stripe-admin.php | Admin menu and scripts |
| `TMW_Stripe_Settings` | class-tmw-stripe-settings.php | Stripe settings tab |
| `TMW_Stripe_Subscribers` | class-tmw-stripe-subscribers.php | WP_List_Table for subscribers |
| `TMW_Stripe_Public` | class-tmw-stripe-public.php | Frontend scripts, user registration |

---

## Database

### Table: `{prefix}tmw_stripe_subscriptions`

Stores subscription records (minimal data, no personal information):

```sql
CREATE TABLE {prefix}tmw_stripe_subscriptions (
    id bigint(20) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id bigint(20) UNSIGNED NOT NULL,
    stripe_customer_id varchar(255) NOT NULL,
    stripe_subscription_id varchar(255) DEFAULT NULL,
    tier_slug varchar(50) NOT NULL DEFAULT 'free',
    status varchar(20) NOT NULL DEFAULT 'active',
    current_period_start datetime DEFAULT NULL,
    current_period_end datetime DEFAULT NULL,
    trial_used tinyint(1) NOT NULL DEFAULT 0,
    canceled_at datetime DEFAULT NULL,
    created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY user_id (user_id),
    KEY stripe_customer_id (stripe_customer_id),
    KEY stripe_subscription_id (stripe_subscription_id),
    KEY status (status)
);
```

### User Meta

| Key | Description |
|-----|-------------|
| `tmw_stripe_customer_id` | Stripe customer ID |
| `tmw_stripe_subscription_id` | Stripe subscription ID |
| `tmw_subscription_tier` | Current tier slug |
| `tmw_subscription_status` | Status (active, trialing, canceled, past_due) |
| `tmw_subscription_current_period_end` | Billing period end date |
| `tmw_stripe_trial_used` | Whether user has used free trial (0/1) |

### WordPress Options

| Option | Description |
|--------|-------------|
| `tmw_stripe_settings` | API keys, webhook secret, trial days, behavior settings |
| `tmw_tiers` (extended) | Adds `stripe_price_id_monthly`, `stripe_price_id_yearly`, `stripe_product_id` |
| `tmw_stripe_db_version` | Database schema version |

---

## WordPress Hooks

### Actions

```php
// When subscription tier changes
do_action('tmw_subscription_changed', $user_id, $old_tier, $new_tier);

// When subscription status changes
do_action('tmw_subscription_status_changed', $user_id, $new_status);

// After successful Stripe checkout
do_action('tmw_stripe_checkout_completed', $user_id, $subscription_data);

// When subscription is canceled
do_action('tmw_stripe_subscription_canceled', $user_id, $subscription_id);

// When payment fails
do_action('tmw_stripe_payment_failed', $user_id, $invoice);

// When trial is about to end
do_action('tmw_stripe_trial_will_end', $user_id, $subscription);

// When new user registers with tier
do_action('tmw_user_registered_with_tier', $user_id, $tier_slug);
```

### Filters

```php
// Modify checkout session parameters
apply_filters('tmw_stripe_checkout_params', $params, $user_id, $tier_slug, $period);

// Modify trial days per user/tier
apply_filters('tmw_stripe_trial_days', $days, $user_id, $tier_slug);

// Modify portal return URL
apply_filters('tmw_stripe_portal_return_url', $url, $user_id);

// Extend tier data sanitization
apply_filters('tmw_sanitize_tier_data', $tier_data);

// Add tabs to admin settings
apply_filters('tmw_admin_tabs', $tabs);
```

---

## Stripe Configuration

### Required Stripe Products & Prices

For each paid tier, create in Stripe Dashboard:

1. **Product** (optional but recommended):
   - Name: "Paid Plan" / "Fleet Plan"
   - Product ID: `prod_xxxxx`

2. **Monthly Price**:
   - Type: Recurring
   - Interval: Monthly
   - Price ID: `price_xxxxx`

3. **Yearly Price**:
   - Type: Recurring
   - Interval: Yearly
   - Price ID: `price_yyyyy`

### Webhook Configuration

In Stripe Dashboard → Webhooks:

1. Add endpoint: `https://yourdomain.com/wp-json/tmw-stripe/v1/webhook`
2. Select events:
   - `checkout.session.completed`
   - `customer.subscription.created`
   - `customer.subscription.updated`
   - `customer.subscription.deleted`
   - `invoice.payment_succeeded`
   - `invoice.payment_failed`
   - `customer.subscription.trial_will_end` (optional)
3. Copy Signing Secret: `whsec_xxxxx`

### Customer Portal

In Stripe Dashboard → Settings → Billing → Customer Portal:

1. Enable "Allow customers to switch plans"
2. Enable "Allow customers to cancel subscriptions"
3. Set cancellation to "At end of billing period"
4. Add your products

---

## User Flows

### New User Registration
```
WordPress registration
    ↓
Hook: user_register
    ↓
TMW_Stripe_Public::on_user_register()
    ↓
Assign free tier (configurable in settings)
Create subscription record in database
Optionally create Stripe customer
```

### Subscribe Flow (Free → Paid)
```
User clicks "Subscribe" button
    ↓
tmw-stripe-public.js handles click
    ↓
AJAX: wp_ajax_tmw_stripe_checkout
    ↓
TMW_Stripe_Checkout::create_checkout_session()
    - Gets price_id from tier settings
    - Adds trial if enabled and not used
    - Sets metadata (user_id, tier_slug)
    ↓
Redirect to Stripe Checkout
    ↓
User completes payment
    ↓
Stripe sends webhook: checkout.session.completed
    ↓
TMW_Stripe_Webhook::handle_checkout_completed()
    - Updates database record
    - Updates user meta
    - Fires tmw_subscription_changed action
    ↓
Redirect to success URL
```

### Manage Subscription
```
User clicks "Manage Subscription"
    ↓
AJAX: wp_ajax_tmw_stripe_portal
    ↓
TMW_Stripe_Portal::create_portal_session()
    ↓
Redirect to Stripe Customer Portal
    ↓
User makes changes (upgrade/downgrade/cancel/update card)
    ↓
Stripe sends webhook (customer.subscription.updated)
    ↓
Database and user meta updated
```

### Plan Change via Portal
```
User upgrades Paid → Fleet in Portal
    ↓
Stripe: customer.subscription.updated
    - New price_id in items
    - Proration charged immediately
    ↓
TMW_Stripe_Webhook::handle_subscription_updated()
    - Detects tier from price_id
    - Updates tier_slug in database
    - Updates user meta
    ↓
User has Fleet access immediately
```

### Cancellation
```
User cancels in Portal
    ↓
Stripe sets cancel_at_period_end = true
    ↓
Webhook: customer.subscription.updated
    ↓
status = 'canceled', canceled_at set
User keeps access until current_period_end
    ↓
At period end: customer.subscription.deleted
    ↓
Revert to free tier
```

---

## Theme Integration

### Adapter Pattern

The plugin provides `TMW_Stripe_Adapter` implementing `TMW_Membership_Adapter_Interface`:

```php
interface TMW_Membership_Adapter_Interface {
    public function get_user_tier($user_id);      // Returns tier slug
    public function is_active($user_id);          // Returns bool
    public function get_expiry_date($user_id);    // Returns date string
    public function get_level_id($user_id);       // Returns level ID (for compat)
    public function is_plugin_active();           // Returns bool
}
```

### Generic URL Functions

Templates should use these functions (work with any adapter):

```php
// Get checkout URL for subscribing
tmw_get_subscribe_url($tier_slug, $period = 'monthly');

// Get subscription management URL
tmw_get_manage_subscription_url();

// Get cancel URL (same as manage for Stripe)
tmw_get_cancel_subscription_url();

// Check if Stripe is active adapter
tmw_is_stripe_active();
```

### Theme Files to Modify

| File | Changes |
|------|---------|
| `inc/membership-adapter.php` | Add `case 'stripe':` to factory |
| `inc/admin-settings.php` | Add Stripe to dropdown, hooks for tab/fields |
| `inc/subscription.php` | Add generic URL functions |
| `templates/template-pricing.php` | Use generic subscribe buttons |
| `templates/template-profile.php` | Use generic manage subscription |
| `templates/template-renewal.php` | Use generic URLs |

See `THEME_MODIFICATIONS.md` for detailed code changes.

---

## Admin Pages

### Stripe Settings Tab
Location: TrackMyWrench → Settings → Stripe

- API mode (Test/Live)
- API keys (publishable, secret)
- Webhook secret
- Success/Cancel URLs
- Trial settings (enabled, days)
- Proration behavior
- Default tier for new users

### Subscribers Management
Location: TrackMyWrench → Subscribers

- List table: User, Tier, Status, Subscription ID, Period End
- Filter by tier/status
- Search by subscription ID
- Links to view in Stripe Dashboard

---

## Testing

### Stripe CLI
```bash
# Forward webhooks to local
stripe listen --forward-to localhost/wp-json/tmw-stripe/v1/webhook

# Trigger test events
stripe trigger checkout.session.completed
stripe trigger customer.subscription.updated
```

### Test Cards
- Success: `4242424242424242`
- Decline: `4000000000000002`
- 3D Secure: `4000002500003155`

---

## Troubleshooting

### Common Issues

**"Invalid API Key"**
- Check mode matches key prefix (pk_test vs pk_live)
- Verify key copied without spaces

**"Webhook signature verification failed"**
- Ensure webhook secret matches Stripe Dashboard
- Check raw POST body is used (not parsed)

**"User not found"**
- Verify metadata.user_id in Checkout Session
- Check WordPress user exists

**"Trial not applying"**
- Check trial_used flag in database
- Verify trial_enabled in settings
- Ensure tier is not free

**"Price not found for tier"**
- Check stripe_price_id_monthly set in tier settings
- Verify price exists in Stripe Dashboard
