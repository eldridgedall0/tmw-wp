# TMW Theme Modifications for Stripe Integration

This document contains the modifications needed to the tmw-wp theme to support the Stripe subscription plugin.

---

## 1. inc/membership-adapter.php

Add the Stripe adapter to the factory function. Find the `tmw_get_membership_adapter()` function and add a new case:

```php
// Around line 50, in the switch statement
case 'stripe':
    // Load Stripe adapter from plugin if active
    if (class_exists('TMW_Stripe_Adapter')) {
        $adapter = new TMW_Stripe_Adapter();
    } else {
        // Fallback to user-meta if plugin not active
        require_once TMW_THEME_DIR . '/inc/adapters/user-meta.php';
        $adapter = new TMW_User_Meta_Adapter();
    }
    break;
```

Also update `tmw_detect_membership_plugins()` to detect Stripe:

```php
// Add after the existing plugin detections
// Stripe (TMW Stripe Subscriptions plugin)
if (class_exists('TMW_Stripe_Subscriptions') || defined('TMW_STRIPE_VERSION')) {
    $active[] = 'stripe';
}
```

---

## 2. inc/admin-settings.php

### 2a. Add 'stripe' option to membership_plugin dropdown

Find the membership_plugin select field (around line 200-250) and add:

```php
<option value="stripe" <?php selected($membership_plugin, 'stripe'); ?>>
    <?php _e('Stripe Subscriptions', 'flavor-starter-flavor'); ?>
</option>
```

### 2b. Hook for Stripe settings tab

Add this filter after the existing tabs array (around line 100):

```php
$tabs = apply_filters('tmw_admin_tabs', $tabs);
```

And in the tab rendering section, add:

```php
// After the existing tab content cases
case 'stripe':
    do_action('tmw_render_stripe_tab');
    break;
```

### 2c. Hook for tier modal Stripe fields

In the tier modal HTML (around line 400-500), add after the SWPM Level ID field:

```php
<?php
// Hook for additional tier fields (Stripe plugin uses this)
do_action('tmw_tier_modal_fields');
?>
```

### 2d. Extend tier data sanitization

In the tier save AJAX handler, add filter:

```php
$tier_data = apply_filters('tmw_sanitize_tier_data', $tier_data);
```

---

## 3. inc/subscription.php

Add generic URL helper functions at the end of the file:

```php
// =============================================================================
// GENERIC SUBSCRIPTION URL HELPERS
// =============================================================================

/**
 * Get subscribe/checkout URL for a tier
 * Works with any membership plugin based on settings
 *
 * @param string $tier_slug Tier slug
 * @param string $period 'monthly' or 'yearly'
 * @return string URL
 */
function tmw_get_subscribe_url($tier_slug, $period = 'monthly') {
    $plugin = tmw_get_setting('membership_plugin', 'simple-membership');

    switch ($plugin) {
        case 'stripe':
            // Stripe plugin provides this function
            if (function_exists('TMW_Stripe_Checkout::get_checkout_url')) {
                return TMW_Stripe_Checkout::get_checkout_url($tier_slug, $period);
            }
            // Fallback: AJAX URL
            return add_query_arg(array(
                'action' => 'tmw_stripe_checkout',
                'tier'   => $tier_slug,
                'period' => $period,
                'nonce'  => wp_create_nonce('tmw_stripe_checkout'),
            ), admin_url('admin-ajax.php'));

        case 'simple-membership':
        default:
            $tier = tmw_get_tier($tier_slug);
            $level_id = $tier['swpm_level_id'] ?? 0;
            return tmw_get_swpm_join_url($level_id);
    }
}

/**
 * Get subscription management URL
 * Works with any membership plugin based on settings
 *
 * @return string URL
 */
function tmw_get_manage_subscription_url() {
    $plugin = tmw_get_setting('membership_plugin', 'simple-membership');

    switch ($plugin) {
        case 'stripe':
            // Stripe plugin provides this function
            if (function_exists('TMW_Stripe_Portal::get_portal_url')) {
                return TMW_Stripe_Portal::get_portal_url();
            }
            // Fallback: AJAX URL
            return add_query_arg(array(
                'action' => 'tmw_stripe_portal',
                'nonce'  => wp_create_nonce('tmw_stripe_portal'),
            ), admin_url('admin-ajax.php'));

        case 'simple-membership':
        default:
            return tmw_get_swpm_profile_url();
    }
}

/**
 * Get cancel subscription URL
 * For Stripe, this redirects to portal (cancel is handled there)
 *
 * @return string URL
 */
function tmw_get_cancel_subscription_url() {
    return tmw_get_manage_subscription_url();
}

/**
 * Check if current membership plugin is Stripe
 *
 * @return bool
 */
function tmw_is_stripe_active() {
    $plugin = tmw_get_setting('membership_plugin', 'simple-membership');
    return $plugin === 'stripe';
}
```

---

## 4. templates/template-pricing.php

### Replace SWPM-specific subscribe buttons with generic function:

**BEFORE:**
```php
<a href="<?php echo esc_url(tmw_get_swpm_join_url($paid_level_id)); ?>" class="tmw-btn tmw-btn-primary tmw-btn-full">
    <?php _e('Subscribe Now', 'flavor-starter-flavor'); ?>
</a>
<?php echo do_shortcode('[swpm_payment_button id="88"]'); ?>
```

**AFTER:**
```php
<?php if (tmw_is_stripe_active()) : ?>
    <button type="button" 
            class="tmw-btn tmw-btn-primary tmw-btn-full tmw-subscribe-btn" 
            data-tier="paid"
            data-period="monthly">
        <?php _e('Subscribe Now', 'flavor-starter-flavor'); ?>
    </button>
<?php else : ?>
    <a href="<?php echo esc_url(tmw_get_subscribe_url('paid')); ?>" class="tmw-btn tmw-btn-primary tmw-btn-full">
        <?php _e('Subscribe Now', 'flavor-starter-flavor'); ?>
    </a>
<?php endif; ?>
```

### For Fleet tier:

**BEFORE:**
```php
<a href="<?php echo esc_url(tmw_get_swpm_join_url($fleet_level_id)); ?>" class="tmw-btn tmw-btn-secondary tmw-btn-full">
    <?php _e('Go Fleet', 'flavor-starter-flavor'); ?>
</a>
```

**AFTER:**
```php
<?php if (tmw_is_stripe_active()) : ?>
    <button type="button" 
            class="tmw-btn tmw-btn-secondary tmw-btn-full tmw-subscribe-btn" 
            data-tier="fleet"
            data-period="monthly">
        <?php _e('Go Fleet', 'flavor-starter-flavor'); ?>
    </button>
<?php else : ?>
    <a href="<?php echo esc_url(tmw_get_subscribe_url('fleet')); ?>" class="tmw-btn tmw-btn-secondary tmw-btn-full">
        <?php _e('Go Fleet', 'flavor-starter-flavor'); ?>
    </a>
<?php endif; ?>
```

### Update pricing toggle to set data-period:

Add JavaScript to update button data-period when toggle changes:

```html
<script>
document.addEventListener('DOMContentLoaded', function() {
    var toggle = document.querySelector('.tmw-pricing-switch');
    if (toggle) {
        toggle.addEventListener('change', function() {
            var period = this.checked ? 'yearly' : 'monthly';
            document.querySelectorAll('.tmw-subscribe-btn').forEach(function(btn) {
                btn.dataset.period = period;
            });
        });
    }
});
</script>
```

---

## 5. templates/template-profile.php

### Replace SWPM cancel shortcode with generic manage subscription:

**BEFORE:**
```php
<a href="<?php echo esc_url(tmw_get_swpm_profile_url()); ?>" class="tmw-btn tmw-btn-secondary" style="display:none">
    <?php _e('Manage Subscription', 'flavor-starter-flavor'); ?>
</a>
<?php echo do_shortcode('[swpm_stripe_subscription_cancel_link merchant_id="ABC123XYZ" anchor_text="Cancel Subscription" new_window="1"]'); ?>
```

**AFTER:**
```php
<?php if (tmw_is_stripe_active()) : ?>
    <button type="button" class="tmw-btn tmw-btn-secondary tmw-stripe-portal-btn">
        <?php _e('Manage Subscription', 'flavor-starter-flavor'); ?>
    </button>
<?php else : ?>
    <a href="<?php echo esc_url(tmw_get_manage_subscription_url()); ?>" class="tmw-btn tmw-btn-secondary">
        <?php _e('Manage Subscription', 'flavor-starter-flavor'); ?>
    </a>
<?php endif; ?>
```

---

## 6. templates/template-renewal.php

### Replace SWPM URLs with generic functions:

**BEFORE:**
```php
<a href="<?php echo esc_url(tmw_get_swpm_join_url($paid_level_id)); ?>" class="tmw-btn tmw-btn-primary tmw-btn-full">
    <?php _e('Subscribe Now', 'flavor-starter-flavor'); ?>
</a>
```

**AFTER:**
```php
<?php if (tmw_is_stripe_active()) : ?>
    <button type="button" 
            class="tmw-btn tmw-btn-primary tmw-btn-full tmw-subscribe-btn" 
            data-tier="paid">
        <?php _e('Subscribe Now', 'flavor-starter-flavor'); ?>
    </button>
<?php else : ?>
    <a href="<?php echo esc_url(tmw_get_subscribe_url('paid')); ?>" class="tmw-btn tmw-btn-primary tmw-btn-full">
        <?php _e('Subscribe Now', 'flavor-starter-flavor'); ?>
    </a>
<?php endif; ?>
```

### For manage account links:

**BEFORE:**
```php
<a href="<?php echo esc_url($swpm_profile_url); ?>" class="tmw-btn tmw-btn-secondary tmw-btn-small">
    <?php _e('Manage Account', 'flavor-starter-flavor'); ?>
</a>
```

**AFTER:**
```php
<?php if (tmw_is_stripe_active()) : ?>
    <button type="button" class="tmw-btn tmw-btn-secondary tmw-btn-small tmw-stripe-portal-btn">
        <?php _e('Manage Account', 'flavor-starter-flavor'); ?>
    </button>
<?php else : ?>
    <a href="<?php echo esc_url(tmw_get_manage_subscription_url()); ?>" class="tmw-btn tmw-btn-secondary tmw-btn-small">
        <?php _e('Manage Account', 'flavor-starter-flavor'); ?>
    </a>
<?php endif; ?>
```

---

## Summary of Changes

| File | Type of Change |
|------|----------------|
| `inc/membership-adapter.php` | Add Stripe case to factory |
| `inc/admin-settings.php` | Add Stripe to dropdown, add hooks for tabs/fields |
| `inc/subscription.php` | Add generic URL helper functions |
| `templates/template-pricing.php` | Use generic subscribe URL/buttons |
| `templates/template-profile.php` | Use generic manage subscription |
| `templates/template-renewal.php` | Use generic URLs throughout |

These changes allow the theme to work with either Simple Membership or Stripe Subscriptions based on the admin setting.
